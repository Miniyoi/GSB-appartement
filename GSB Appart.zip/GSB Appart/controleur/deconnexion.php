<?php

include_once "modèle/authentification.php";

logout();

include "controleur/connexion.php";
